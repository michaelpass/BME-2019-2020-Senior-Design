#ifndef testLibrary_h
#define testLibrary_h

#include "Arduino.h"



void convertDectoBCD(int num);


#endif
