#ifndef testLibrary_h
#define testLibrary_h

#include "Arduino.h"

void convertDectoBCD(int num){

    static int BCD[4];

     switch (num){

      case 0:
        BCD[0] = LOW; 
        BCD[1] = LOW; 
        BCD[2] = LOW; 
        BCD[3] = LOW;
        break;

      case 1:
        BCD[0] = LOW; 
        BCD[1] = LOW; 
        BCD[2] = LOW; 
        BCD[3] = HIGH;
        break;

      case 2:
        BCD[0] = LOW; 
        BCD[1] = LOW; 
        BCD[2] = HIGH; 
        BCD[3] = LOW;
        break;
        
      case 3:
        BCD[0] = LOW; 
        BCD[1] = LOW; 
        BCD[2] = HIGH; 
        BCD[3] = HIGH;
        break;

      case 4:
        BCD[0] = LOW; 
        BCD[1] = HIGH; 
        BCD[2] = LOW; 
        BCD[3] = LOW;
        break;

      case 5:
        BCD[0] = LOW; 
        BCD[1] = HIGH; 
        BCD[2] = LOW; 
        BCD[3] = HIGH;
        break;

      case 6:
        BCD[0] = LOW; 
        BCD[1] = HIGH; 
        BCD[2] = HIGH; 
        BCD[3] = LOW;
        break;

      case 7:
        BCD[0] = LOW; 
        BCD[1] = HIGH; 
        BCD[2] = HIGH; 
        BCD[3] = HIGH;
        break;

      case 8:
        BCD[0] = HIGH; 
        BCD[1] = LOW; 
        BCD[2] = LOW; 
        BCD[3] = LOW;
        break;

      case 9:
        BCD[0] = HIGH; 
        BCD[1] = LOW; 
        BCD[2] = LOW; 
        BCD[3] = HIGH;
        break;
      
     }
}



#endif
