

int* convertDectoBCD(int num);
bool getButtonStatus(int pinNumber, int buttonThreshold);