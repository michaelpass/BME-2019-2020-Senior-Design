#include "Arduino.h"
#include "MCP23S17.h"
#define extender1 2

MCP test(0, 10);
int i = 0;

int* convertDectoBCD(int num){

    static int BCD[4];

     switch (num){
      case 0:
        BCD[3] = LOW; BCD[2] = LOW; BCD[1] = LOW; BCD[0] = LOW; break;
      case 1:
        BCD[3] = LOW; BCD[2] = LOW; BCD[1] = LOW; BCD[0] = HIGH; break;
      case 2:
        BCD[3] = LOW; BCD[2] = LOW; BCD[1] = HIGH; BCD[0] = LOW; break;
      case 3:
        BCD[3] = LOW; BCD[2] = LOW; BCD[1] = HIGH; BCD[0] = HIGH; break;
      case 4:
        BCD[3] = LOW; BCD[2] = HIGH; BCD[1] = LOW; BCD[0] = LOW; break;
      case 5:
        BCD[3] = LOW; BCD[2] = HIGH; BCD[1] = LOW; BCD[0] = HIGH; break;
      case 6:
        BCD[3] = LOW; BCD[2] = HIGH; BCD[1] = HIGH; BCD[0] = LOW; break;
      case 7:
        BCD[3] = LOW; BCD[2] = HIGH; BCD[1] = HIGH; BCD[0] = HIGH; break;
      case 8:
        BCD[3] = HIGH; BCD[2] = LOW; BCD[1] = LOW; BCD[0] = LOW; break;
      case 9:
        BCD[3] = HIGH; BCD[2] = LOW; BCD[1] = LOW; BCD[0] = HIGH; break;
     }

    Serial.println("Alternative");
    return BCD;
} 

void writeNumberTo7Seg(int num){

int firstDigit = num % 10;
int secondDigit = (num / 10) % 10;
int thirdDigit = (num / 100) % 10;

int * firstDigit_BCD = convertDectoBCD(firstDigit);
test.digitalWrite(1, firstDigit_BCD[0]);
test.digitalWrite(2, firstDigit_BCD[1]);
test.digitalWrite(3, firstDigit_BCD[2]);
test.digitalWrite(4, firstDigit_BCD[3]);

int * secondDigit_BCD = convertDectoBCD(secondDigit);
test.digitalWrite(5, secondDigit_BCD[0]);
test.digitalWrite(6, secondDigit_BCD[1]);
test.digitalWrite(7, secondDigit_BCD[2]);
test.digitalWrite(8, secondDigit_BCD[3]);

int * thirdDigit_BCD = convertDectoBCD(thirdDigit);
test.digitalWrite(9, thirdDigit_BCD[0]);
test.digitalWrite(10, thirdDigit_BCD[1]);
test.digitalWrite(11, thirdDigit_BCD[2]);
test.digitalWrite(12, thirdDigit_BCD[3]);

Serial.print("Reached "); Serial.print(num); Serial.println(firstDigit_BCD[0]);
}


void setup(){
/*
test.pinMode(0, LOW);
test.pinMode(1, LOW);
test.pinMode(2, LOW);
test.pinMode(3, LOW);

test.pinMode(4, LOW);
test.pinMode(5, LOW);
test.pinMode(6, LOW);
test.pinMode(7, LOW);

test.pinMode(8, LOW);
test.pinMode(9, LOW);
test.pinMode(10, LOW);
test.pinMode(11, LOW);
*/
test.begin();

// 7seg Display - (Pins 1-4 LSB)
test.pinMode(1, OUTPUT);
test.pinMode(2, OUTPUT);
test.pinMode(3, OUTPUT);
test.pinMode(4, OUTPUT);
test.pinMode(5, OUTPUT);
test.pinMode(6, OUTPUT);
test.pinMode(7, OUTPUT);
test.pinMode(8, OUTPUT);
test.pinMode(9, OUTPUT);
test.pinMode(10, OUTPUT);
test.pinMode(11, OUTPUT);
test.pinMode(12, OUTPUT);

test.digitalWrite(1, LOW);
test.digitalWrite(2, LOW);
test.digitalWrite(3, LOW);
test.digitalWrite(4, LOW);
test.digitalWrite(5, LOW);
test.digitalWrite(6, LOW);
test.digitalWrite(7, LOW);
test.digitalWrite(8, LOW);
test.digitalWrite(9, LOW);
test.digitalWrite(10, LOW);
test.digitalWrite(11, LOW);
test.digitalWrite(12, LOW);

Serial.begin(9600);

}


void loop(){

writeNumberTo7Seg(i);
/*
test.digitalWrite(1, HIGH);
test.digitalWrite(2, LOW);
test.digitalWrite(3, LOW);
test.digitalWrite(4, HIGH);

test.digitalWrite(5, HIGH);
test.digitalWrite(6, LOW);
test.digitalWrite(7, LOW);
test.digitalWrite(8, HIGH);
*/


/*
analogWrite(9, 125);
analogWrite(10, 125);
analogWrite(11, 75);
digitalWrite(12, HIGH);
*/
delay(1000);

++i;
if(i > 999){
    i = 0;
}

}